      var dosbox = new Dosbox({
        id: "dosbox",
        onload: function (dosbox) {
          dosbox.run("https://js-dos.com/cdn/upload/Duke Nukem 3d-@digitalwalt.zip", "./DUKE3D/DUKE3D.EXE");
        },
        onrun: function (dosbox, app) {
          console.log("App '" + app + "' is runned");
        }
      });